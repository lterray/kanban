var parameters = {
    fieldList: [
        {name: "Id", map: "id", location: "hidden"},
        {name: "Summary", map: "title", location: "header", link: "http://examplelink.com/{id}"},
        {name: "Issue State", map: "state", location: "content", cssClass: "state"},
        {name: "Owner", map: "assignee", location: "content"},
        {name: "Priority", map: "priority", location: "footer"},
        {name: "Last Changed", map: "lastEdit", location: "footer"}
    ],
    source: [
        {id: "12", title: "Go to the laundry", state: "Created", assignee: "Tyrion", priority: 9, lastEdit: "2016.06.06"},
        {id: "13", title: "Feed the dog", state: "Ready", assignee: "Arya", priority: 4, lastEdit: "2016.06.11"},
        {id: "14", title: "Dishwashing", state: "InProgress", assignee: "Tyrion", priority: 6, lastEdit: "2016.06.03"},
        {id: "15", title: "Mowing", state: "Created", assignee: "Unassigned", priority: 2, lastEdit: "2016.06.01"},
        {id: "16", title: "Cooking", state: "Ready", assignee: "Unassigned", priority: 4, lastEdit: "2016.06.24"}
    ],
    config: {
        columnField: "state",
        columns: [{name: "Created", value: 0, limit: 3}, {name: "InProgress", value: 1, limit: 3}, {name: "Ready", value: 2, limit: 3}, {name: "Archived", value: 3, limit: 3}],
        rowField: "assignee",
        rows: [{name: "Unassigned", value: 'ua', limit: 3}, {name: "Tyrion", value: 13, limit: 3}, {name: "Arya", value: 17, limit: 3}],
        colorField: "priority",
        colorValues: {1: "#33cc33", 2: "#33cc33", 3: "#33cc33", 4: "yellow", 5: "yellow", 6: "yellow", 7: "yellow", 8: "#ffcccc", 9: "#ffcccc", 10: "#ffcccc"},
        transactionUrl: "serverOk.html",
        //transactionUrl: "serverError.html",
        transactionCallback: function (droppedItem) {
            // if returns false then element gets back to its original position
            return true;
        }
    }
}

var kg = kanbanGrid(parameters, '#interactGridTest');
